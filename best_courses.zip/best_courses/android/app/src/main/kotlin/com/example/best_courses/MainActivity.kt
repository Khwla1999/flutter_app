package com.example.best_courses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
